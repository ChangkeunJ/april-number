#!/bin/sh
echo this member must never be extracted
